/* ==========================================================================
   AM-Pay™ Network — Shared site behaviour
========================================================================== */

/* Shared validator: checks every [required] field inside `container` (a form,
   or a single wizard step), toggling `.invalid` on its `.field`/`.check-row`
   wrapper, and — if both a password and password_confirm input are present
   inside the container — confirms they match. Returns true when everything
   in that container passes. Used by both the multi-step wizard's "Continue"
   buttons and the final form submit, so a mismatched password can never slip
   through to a "success" state. */
function validateContainer(container) {
  let valid = true;
  container.querySelectorAll('[required]').forEach(input => {
    const field = input.closest('.field') || input.closest('.check-row');
    const empty = input.type === 'checkbox' ? !input.checked : !input.value.trim();
    if (empty) { valid = false; field && field.classList.add('invalid'); }
    else { field && field.classList.remove('invalid'); }
  });

  const pw = container.querySelector('input[type="password"][name="password"], input[name="password"]');
  const pwConfirm = container.querySelector('input[name="password_confirm"]');
  if (pw && pwConfirm) {
    const field = pwConfirm.closest('.field');
    if (pwConfirm.value && pw.value !== pwConfirm.value) {
      valid = false;
      field && field.classList.add('invalid');
      const err = field && field.querySelector('.field-error');
      if (err) err.textContent = 'Passwords do not match.';
    } else if (pwConfirm.value) {
      field && field.classList.remove('invalid');
    }
  }
  return valid;
}

document.addEventListener('DOMContentLoaded', () => {

  /* --- Nav scroll shadow --- */
  const nav = document.querySelector('.nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 24);
    }, { passive: true });
  }

  /* --- Mobile nav drawer --- */
  const burger = document.querySelector('.nav-burger');
  const mobileNav = document.querySelector('.mobile-nav');
  const mobileClose = document.querySelector('.mobile-nav-close');
  if (burger && mobileNav) {
    burger.addEventListener('click', () => mobileNav.classList.add('open'));
    mobileNav.addEventListener('click', (e) => { if (e.target === mobileNav) mobileNav.classList.remove('open'); });
  }
  if (mobileClose && mobileNav) {
    mobileClose.addEventListener('click', () => mobileNav.classList.remove('open'));
  }

  /* --- Scroll-triggered reveal --- */
  const revealSelectors = [
    '.sec-pill', '.section > h2', '.section > .sub', '.section-head',
    '.two-col-text', '.feature-card', '.p-card', '.int-badge',
    '.integration .int-heading', '.integration .int-sub',
    '.cta-strip h2', '.cta-strip p', '.cta-actions',
    '.industry-card', '.problem-card', '.page-header h1', '.page-header p'
  ];
  revealSelectors.forEach(sel => {
    document.querySelectorAll(sel).forEach(el => el.classList.add('reveal'));
  });

  ['features-grid', 'pricing-grid', 'industry-grid', 'problem-grid'].forEach(cls => {
    document.querySelectorAll('.' + cls).forEach(grid => {
      Array.from(grid.children).forEach((card, i) => {
        card.classList.add('reveal', `delay-${Math.min(i + 1, 6)}`);
      });
    });
  });
  document.querySelectorAll('.int-badges .int-badge').forEach((el, i) => el.classList.add(`delay-${i + 1}`));

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -36px 0px' });
  document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

  /* --- Mock-row slide-in --- */
  document.querySelectorAll('.mock-panel').forEach(panel => {
    const panelObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.mock-row').forEach((row, i) => {
            setTimeout(() => row.classList.add('visible'), i * 110);
          });
          panelObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.25 });
    panelObserver.observe(panel);
  });

  /* --- Stats count-up --- */
  function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }
  function countUp(el, targetText) {
    const match = targetText.match(/^([R₹]*)(\d+\.?\d*)(.*)$/);
    if (!match) return;
    const prefix = match[1], target = parseFloat(match[2]), suffix = match[3];
    const isFloat = String(target).includes('.');
    const duration = 1600, startTime = performance.now();
    function tick(now) {
      const t = Math.min((now - startTime) / duration, 1);
      const val = easeOutCubic(t) * target;
      el.textContent = prefix + (isFloat ? val.toFixed(1) : Math.round(val)) + suffix;
      if (t < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  document.querySelectorAll('.stats-strip, .market-stats').forEach(strip => {
    const statsObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.stat-num, .m-num').forEach(el => {
            const original = el.dataset.original || el.textContent.trim();
            el.dataset.original = original;
            countUp(el, original);
          });
          statsObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    statsObserver.observe(strip);
  });

  /* --- Smooth scroll for in-page anchors --- */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      const id = link.getAttribute('href');
      if (id.length < 2) return;
      const target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* --- FAQ accordion --- */
  document.querySelectorAll('.faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const item = q.closest('.faq-item');
      const wasOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  /* --- Developers page: mini terminal header card cycles Sending → 200 OK.
     No-op everywhere else since .header-api-card only exists on developers.html. */
  const apiCardStatus = document.querySelector('.header-api-card-status');
  if (apiCardStatus) {
    const apiDot = apiCardStatus.querySelector('.header-api-card-dot');
    const apiText = apiCardStatus.querySelector('.header-api-card-status-text');
    let apiSending = true;
    function cycleApiCardStatus() {
      if (apiSending) {
        apiDot.className = 'header-api-card-dot sending';
        apiText.textContent = 'Sending request…';
      } else {
        apiDot.className = 'header-api-card-dot ok';
        apiText.textContent = '200 OK · 118ms';
      }
      apiSending = !apiSending;
    }
    setInterval(cycleApiCardStatus, 1500);
  }

  /* --- Segmented toggle (signup: individual / business) ---
     Hidden panels must have their `required` fields disarmed, or a hidden,
     empty field silently blocks validation on the visible panel. We stash
     the original required-ness in data-was-required so it can be restored
     if the user switches back. */
  document.querySelectorAll('.seg-toggle').forEach(toggle => {
    const buttons = toggle.querySelectorAll('button');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const target = btn.dataset.target;
        document.querySelectorAll('[data-panel]').forEach(p => {
          const isTarget = p.dataset.panel === target;
          p.style.display = isTarget ? 'block' : 'none';
          p.querySelectorAll('input, select, textarea').forEach(field => {
            if (isTarget) {
              if (field.dataset.wasRequired === '1') { field.required = true; delete field.dataset.wasRequired; }
            } else if (field.required) {
              field.dataset.wasRequired = '1';
              field.required = false;
              const wrap = field.closest('.field');
              if (wrap) wrap.classList.remove('invalid');
            }
          });
        });
      });
    });
    // Ensure the panel matching the initially-active button is required-correct on load.
    const initialActive = toggle.querySelector('button.active') || buttons[0];
    if (initialActive) initialActive.click();
  });

  /* --- Password show/hide + strength meter --- */
  document.querySelectorAll('.pw-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input');
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      btn.innerHTML = showing ? '<i class="ti ti-eye"></i>' : '<i class="ti ti-eye-off"></i>';
    });
  });

  document.querySelectorAll('input[data-strength]').forEach(input => {
    const bars = document.querySelectorAll(input.dataset.strength + ' span');
    const label = document.querySelector(input.dataset.strengthLabel);
    input.addEventListener('input', () => {
      const v = input.value;
      let score = 0;
      if (v.length >= 8) score++;
      if (/[A-Z]/.test(v)) score++;
      if (/[0-9]/.test(v)) score++;
      if (/[^A-Za-z0-9]/.test(v)) score++;
      const colors = ['#e5e5e5', '#c0392b', '#e2a03f', '#3d9230', '#4aaa3c'];
      const labels = ['', 'Weak', 'Fair', 'Good', 'Strong'];
      bars.forEach((bar, i) => { bar.style.background = i < score ? colors[score] : '#e5e5e5'; });
      if (label) label.textContent = v ? labels[score] : '';
    });
  });

  /* --- Generic client-side form validation + demo submit --- */
  document.querySelectorAll('form[data-validate]').forEach(form => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const valid = validateContainer(form);
      const alertBox = form.querySelector('.form-alert');
      if (!valid) {
        if (alertBox) {
          alertBox.className = 'form-alert error show';
          alertBox.innerHTML = '<i class="ti ti-alert-circle"></i> Please fill in all required fields correctly.';
        }
        return;
      }
      if (alertBox) {
        alertBox.className = 'form-alert success show';
        alertBox.innerHTML = form.dataset.successMessage
          ? `<i class="ti ti-circle-check"></i> ${form.dataset.successMessage}`
          : '<i class="ti ti-circle-check"></i> Thanks — this demo form isn’t connected to a live backend yet, but your details look good.';
      }
    });
  });

  /* --- Multi-step signup wizard --- */
  const wizard = document.querySelector('[data-wizard]');
  if (wizard) {
    const steps = Array.from(wizard.querySelectorAll('.step-panel'));
    const dots = Array.from(wizard.querySelectorAll('.step-dot'));
    const lines = Array.from(wizard.querySelectorAll('.step-line'));
    let current = 0;

    function render() {
      steps.forEach((s, i) => s.classList.toggle('active', i === current));
      dots.forEach((d, i) => {
        d.classList.toggle('active', i === current);
        d.classList.toggle('done', i < current);
      });
      lines.forEach((l, i) => l.classList.toggle('done', i < current));
    }

    wizard.querySelectorAll('[data-next]').forEach(btn => {
      btn.addEventListener('click', () => {
        const panel = steps[current];
        if (!validateContainer(panel)) return;
        if (current < steps.length - 1) { current++; render(); window.scrollTo({ top: wizard.offsetTop - 100, behavior: 'smooth' }); }
      });
    });
    wizard.querySelectorAll('[data-prev]').forEach(btn => {
      btn.addEventListener('click', () => { if (current > 0) { current--; render(); } });
    });
    render();
  }

});

/* ==========================================================================
   Futuristic fintech layer: live network canvas, payment-flow line pause,
   card tilt, and the AM-Pay Assistant chatbot + WhatsApp FAB.
========================================================================== */
document.addEventListener('DOMContentLoaded', () => {

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* --- Flowing aurora waves (alternate homepage-hero background, opt-in via
     .hero-network-bg--aurora). Layered translucent sine-wave ribbons in the
     brand green/blue, drifting slowly, with a gentle cursor-following bulge.
     Self-contained: sets up its own canvas + listeners and returns, so it
     never touches the particle-network code path below it. --- */
  function runAuroraBackground(netCanvas, onDark) {
    const ctx = netCanvas.getContext('2d');
    const supportsHover = window.matchMedia('(hover: hover)').matches;
    const glowEl = netCanvas.parentElement.querySelector('.hero-network-glow');
    let w, h;
    const mouse = { x: null, active: false };

    function sizeCanvas() {
      const rect = netCanvas.parentElement.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      netCanvas.width = rect.width * dpr;
      netCanvas.height = rect.height * dpr;
      netCanvas.style.width = rect.width + 'px';
      netCanvas.style.height = rect.height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      w = rect.width; h = rect.height;
    }

    const bands = [
      { baseY: 0.30, amp: 24, freq: 0.0060, speed: 0.0060, phase: 0.0, hue: '109,218,155' },
      { baseY: 0.46, amp: 32, freq: 0.0045, speed: -0.0045, phase: 2.1, hue: '77,127,224' },
      { baseY: 0.60, amp: 20, freq: 0.0080, speed: 0.0035, phase: 4.2, hue: '74,170,60' },
      { baseY: 0.74, amp: 28, freq: 0.0050, speed: -0.0025, phase: 1.4, hue: '120,170,255' }
    ];
    const baseAlpha = onDark ? 0.17 : 0.11;

    function tick() {
      ctx.clearRect(0, 0, w, h);
      ctx.globalCompositeOperation = 'lighter';
      const step = Math.max(4, Math.floor(w / 140));

      bands.forEach(band => {
        band.phase += band.speed;
        ctx.beginPath();
        for (let x = -step; x <= w + step; x += step) {
          let y = h * band.baseY + Math.sin(x * band.freq + band.phase) * band.amp;
          if (supportsHover && mouse.active) {
            const dist = Math.abs(x - mouse.x);
            const reach = 260;
            if (dist < reach) {
              const pull = 1 - dist / reach;
              y -= pull * pull * 46;
            }
          }
          if (x === -step) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.lineTo(w + step, h);
        ctx.lineTo(-step, h);
        ctx.closePath();
        const grad = ctx.createLinearGradient(0, h * band.baseY - band.amp - 40, 0, h * band.baseY + 160);
        grad.addColorStop(0, `rgba(${band.hue},${baseAlpha.toFixed(3)})`);
        grad.addColorStop(1, `rgba(${band.hue},0)`);
        ctx.fillStyle = grad;
        ctx.fill();
      });

      ctx.globalCompositeOperation = 'source-over';
      requestAnimationFrame(tick);
    }

    sizeCanvas();
    requestAnimationFrame(tick);

    let resizeTimer;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(sizeCanvas, 200);
    });

    if (supportsHover) {
      const host = netCanvas.parentElement;
      host.addEventListener('mousemove', (e) => {
        const rect = netCanvas.getBoundingClientRect();
        mouse.x = e.clientX - rect.left;
        mouse.active = true;
        if (glowEl) {
          glowEl.style.setProperty('--mx', ((mouse.x / rect.width) * 100).toFixed(1) + '%');
          glowEl.style.setProperty('--my', (((e.clientY - rect.top) / rect.height) * 100).toFixed(1) + '%');
        }
      });
      host.addEventListener('mouseleave', () => { mouse.active = false; });
    }
  }

  /* --- Warping wireframe mesh (alternate homepage-hero background, opt-in via
     .hero-network-bg--wireframe). A grid of lines that idles with a gentle
     ambient ripple and bends toward the cursor like fabric/a topographic
     surface reacting to touch, with a soft glow at the warped intersections.
     Self-contained, same pattern as runAuroraBackground above. --- */
  function runWireframeBackground(netCanvas, onDark) {
    const ctx = netCanvas.getContext('2d');
    const supportsHover = window.matchMedia('(hover: hover)').matches;
    const glowEl = netCanvas.parentElement.querySelector('.hero-network-glow');
    let w, h, cols, rows, cellW, cellH;
    const mouse = { x: null, y: null, active: false };
    const lineColor = onDark ? '255,255,255' : '30,54,116';
    const accentColor = '109,218,155';

    function sizeCanvas() {
      const rect = netCanvas.parentElement.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      netCanvas.width = rect.width * dpr;
      netCanvas.height = rect.height * dpr;
      netCanvas.style.width = rect.width + 'px';
      netCanvas.style.height = rect.height + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      w = rect.width; h = rect.height;
      const targetCell = 46;
      cols = Math.max(6, Math.round(w / targetCell));
      rows = Math.max(5, Math.round(h / targetCell));
      cellW = w / cols;
      cellH = h / rows;
    }

    let t = 0;
    function tick() {
      t += 0.012;
      ctx.clearRect(0, 0, w, h);

      const pts = [];
      for (let r = 0; r <= rows; r++) {
        pts[r] = [];
        for (let c = 0; c <= cols; c++) {
          const bx = c * cellW, by = r * cellH;
          let x = bx, y = by, glow = 0;
          y += Math.sin(bx * 0.018 + t) * 3 + Math.cos(by * 0.022 + t * 0.8) * 3;
          if (supportsHover && mouse.active) {
            const dx = bx - mouse.x, dy = by - mouse.y;
            const dist = Math.sqrt(dx * dx + dy * dy) || 1;
            const radius = 230;
            if (dist < radius) {
              const pull = 1 - dist / radius;
              const factor = pull * pull * 34;
              x -= (dx / dist) * factor;
              y -= (dy / dist) * factor;
              glow = pull;
            }
          }
          pts[r][c] = { x, y, glow };
        }
      }

      const baseAlpha = onDark ? 0.16 : 0.11;
      ctx.strokeStyle = `rgba(${lineColor},${baseAlpha})`;
      ctx.lineWidth = 1;
      for (let r = 0; r <= rows; r++) {
        ctx.beginPath();
        for (let c = 0; c <= cols; c++) {
          const p = pts[r][c];
          if (c === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
        }
        ctx.stroke();
      }
      for (let c = 0; c <= cols; c++) {
        ctx.beginPath();
        for (let r = 0; r <= rows; r++) {
          const p = pts[r][c];
          if (r === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
        }
        ctx.stroke();
      }

      if (supportsHover && mouse.active) {
        for (let r = 0; r <= rows; r++) {
          for (let c = 0; c <= cols; c++) {
            const p = pts[r][c];
            if (p.glow > 0.05) {
              ctx.beginPath();
              ctx.arc(p.x, p.y, 1.4 + p.glow * 1.8, 0, Math.PI * 2);
              ctx.fillStyle = `rgba(${accentColor},${(p.glow * 0.85).toFixed(3)})`;
              if (p.glow > 0.5) { ctx.shadowBlur = 8 * p.glow; ctx.shadowColor = `rgba(${accentColor},0.9)`; }
              ctx.fill();
              ctx.shadowBlur = 0;
            }
          }
        }
      }

      requestAnimationFrame(tick);
    }

    sizeCanvas();
    requestAnimationFrame(tick);

    let resizeTimer;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(sizeCanvas, 200);
    });

    if (supportsHover) {
      const host = netCanvas.parentElement;
      host.addEventListener('mousemove', (e) => {
        const rect = netCanvas.getBoundingClientRect();
        mouse.x = e.clientX - rect.left;
        mouse.y = e.clientY - rect.top;
        mouse.active = true;
        if (glowEl) {
          glowEl.style.setProperty('--mx', ((mouse.x / rect.width) * 100).toFixed(1) + '%');
          glowEl.style.setProperty('--my', ((mouse.y / rect.height) * 100).toFixed(1) + '%');
        }
      });
      host.addEventListener('mouseleave', () => { mouse.active = false; });
    }
  }

  /* --- Live network canvas (hero background) --- */
  document.querySelectorAll('.hero-network-bg').forEach(netCanvas => {
    if (reduceMotion) return;
    const onDark = netCanvas.classList.contains('on-dark');
    if (netCanvas.classList.contains('hero-network-bg--aurora')) {
      runAuroraBackground(netCanvas, onDark);
      return;
    }
    if (netCanvas.classList.contains('hero-network-bg--wireframe')) {
      runWireframeBackground(netCanvas, onDark);
      return;
    }
    /* Homepage hero only: denser field, glow, and cursor reactivity.
       Interior page-header canvases keep the original quiet ambient look untouched. */
    const interactive = netCanvas.classList.contains('hero-network-bg--interactive')
      && window.matchMedia('(hover: hover)').matches;
    const lineColor = onDark ? 'rgba(255,255,255,LINE_A)' : 'rgba(30,54,116,LINE_A)';
    const dotColor = onDark ? 'rgba(109,218,155,0.75)' : 'rgba(74,170,60,0.5)';
    const cursorLineColor = 'rgba(109,218,155,LINE_A)';
    const ctx = netCanvas.getContext('2d');
    let w, h, nodes, t = 0;
    const mouse = { x: null, y: null };
    const glowEl = interactive ? netCanvas.parentElement.querySelector('.hero-network-glow') : null;

    function sizeCanvas() {
      const rect = netCanvas.parentElement.getBoundingClientRect();
      w = netCanvas.width = rect.width * window.devicePixelRatio;
      h = netCanvas.height = rect.height * window.devicePixelRatio;
      netCanvas.style.width = rect.width + 'px';
      netCanvas.style.height = rect.height + 'px';
      ctx.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
    }

    function makeNodes() {
      const rect = netCanvas.parentElement.getBoundingClientRect();
      const divisor = interactive ? 9000 : 22000;
      const cap = interactive ? 85 : 34;
      const count = Math.max(14, Math.min(cap, Math.round((rect.width * rect.height) / divisor)));
      nodes = Array.from({ length: count }, () => ({
        x: Math.random() * rect.width,
        y: Math.random() * rect.height,
        vx: (Math.random() - 0.5) * 0.28,
        vy: (Math.random() - 0.5) * 0.28,
        r: Math.random() * 1.6 + 1,
        phase: Math.random() * Math.PI * 2,
        twinkle: 0.6 + Math.random() * 0.9
      }));
    }

    function tick() {
      const rect = netCanvas.parentElement.getBoundingClientRect();
      t += 0.016;
      ctx.clearRect(0, 0, rect.width, rect.height);
      const linkDist = interactive ? 165 : 140;
      const baseLineAlpha = interactive ? 0.26 : (onDark ? 0.22 : 0.16);

      nodes.forEach(n => {
        if (interactive && mouse.x !== null) {
          const dx = n.x - mouse.x, dy = n.y - mouse.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const radius = 130;
          if (dist < radius) {
            const force = (radius - dist) / radius * 0.9;
            n.vx += (dx / dist) * force;
            n.vy += (dy / dist) * force;
          }
        }
        n.x += n.vx; n.y += n.vy;
        if (interactive) { n.vx *= 0.965; n.vy *= 0.965; }
        const maxV = interactive ? 2.6 : 0.28;
        const speed = Math.sqrt(n.vx * n.vx + n.vy * n.vy);
        if (interactive && speed > maxV) { n.vx = (n.vx / speed) * maxV; n.vy = (n.vy / speed) * maxV; }
        if (interactive && speed < 0.12) { n.vx += (Math.random() - 0.5) * 0.04; n.vy += (Math.random() - 0.5) * 0.04; }
        if (n.x < 0 || n.x > rect.width) n.vx *= -1;
        if (n.y < 0 || n.y > rect.height) n.vy *= -1;
      });

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < linkDist) {
            const alpha = (1 - dist / linkDist) * baseLineAlpha;
            ctx.strokeStyle = lineColor.replace('LINE_A', alpha.toFixed(3));
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
      }

      if (interactive && mouse.x !== null) {
        const cursorReach = 190;
        nodes.forEach(n => {
          const dx = n.x - mouse.x, dy = n.y - mouse.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < cursorReach) {
            const alpha = (1 - dist / cursorReach) * 0.55;
            ctx.strokeStyle = cursorLineColor.replace('LINE_A', alpha.toFixed(3));
            ctx.lineWidth = 1.1;
            ctx.beginPath(); ctx.moveTo(mouse.x, mouse.y); ctx.lineTo(n.x, n.y); ctx.stroke();
          }
        });
        ctx.beginPath();
        ctx.arc(mouse.x, mouse.y, 3, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(109,218,155,0.9)';
        ctx.shadowBlur = 12; ctx.shadowColor = 'rgba(109,218,155,0.9)';
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      nodes.forEach(n => {
        const flicker = interactive ? (0.7 + 0.3 * Math.sin(t * n.twinkle + n.phase)) : 1;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fillStyle = dotColor;
        ctx.globalAlpha = flicker;
        if (interactive) { ctx.shadowBlur = 5; ctx.shadowColor = dotColor; }
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1;
      });

      requestAnimationFrame(tick);
    }

    sizeCanvas();
    makeNodes();
    requestAnimationFrame(tick);
    let resizeTimer;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => { sizeCanvas(); makeNodes(); }, 200);
    });

    if (interactive) {
      const host = netCanvas.parentElement;
      host.addEventListener('mousemove', (e) => {
        const rect = netCanvas.getBoundingClientRect();
        mouse.x = e.clientX - rect.left;
        mouse.y = e.clientY - rect.top;
        if (glowEl) {
          glowEl.style.setProperty('--mx', ((mouse.x / rect.width) * 100).toFixed(1) + '%');
          glowEl.style.setProperty('--my', ((mouse.y / rect.height) * 100).toFixed(1) + '%');
        }
      });
      host.addEventListener('mouseleave', () => { mouse.x = null; mouse.y = null; });
    }
  });

  /* --- Pause the animated flow-line dot when reduced motion is preferred --- */
  if (reduceMotion) {
    document.querySelectorAll('.flow-dot').forEach(dot => {
      const anim = dot.querySelector('animateMotion');
      if (anim) anim.setAttribute('begin', 'indefinite');
    });
  }

  /* --- Subtle 3D tilt on feature / industry / pricing cards --- */
  if (!reduceMotion && window.matchMedia('(hover: hover)').matches) {
    document.querySelectorAll('.feature-card, .industry-card, .p-card').forEach(card => {
      card.classList.add('tilt-card');
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width - 0.5;
        const py = (e.clientY - rect.top) / rect.height - 0.5;
        card.style.setProperty('--ry', `${px * 7}deg`);
        card.style.setProperty('--rx', `${-py * 7}deg`);
      });
      card.addEventListener('mouseleave', () => {
        card.style.setProperty('--rx', '0deg');
        card.style.setProperty('--ry', '0deg');
      });
    });
  }

  /* --- WhatsApp / Chatbot floating action buttons --- */
  const chatToggle = document.querySelector('.fab-bot');
  const chatPanel = document.querySelector('.chat-panel');
  const chatClose = document.querySelector('.chat-close');
  if (chatToggle && chatPanel) {
    chatToggle.addEventListener('click', () => {
      chatPanel.classList.toggle('open');
      if (chatPanel.classList.contains('open')) {
        const input = chatPanel.querySelector('.chat-input-row input');
        input && input.focus();
      }
    });
  }
  if (chatClose && chatPanel) {
    chatClose.addEventListener('click', () => chatPanel.classList.remove('open'));
  }

  /* --- AM-Pay Assistant: small rule-based FAQ bot --- */
  const chatBody = document.querySelector('.chat-body');
  const chatForm = document.querySelector('.chat-input-row');
  const chatInput = chatForm ? chatForm.querySelector('input') : null;

  const KB = [
    { keys: ['price', 'pricing', 'fee', 'fees', 'cost', 'how much'],
      reply: 'Personal accounts are free. Business is R299/month plus a per-transaction fee for DebiCheck and Pay Now. Enterprise pricing is custom. Full breakdown: <a href="pricing.html">Pricing &amp; Fees</a>.' },
    { keys: ['debicheck', 'debit order', 'mandate'],
      reply: 'DebiCheck is our authenticated debit order product — the mandate is confirmed by the debtor\'s bank, which gives it the lowest dispute rate of any collection method. It\'s live today. More: <a href="products.html#debicheck">DebiCheck &amp; Debit Orders</a>.' },
    { keys: ['pay now', 'gateway', 'card payment', 'eft', 'checkout'],
      reply: 'Pay Now is our online payment gateway — accept once-off or recurring payments by card or Instant EFT. It\'s live now via our Netcash ISV partnership. See <a href="products.html#gateway">Online Payment Gateway</a>.' },
    { keys: ['sign up', 'signup', 'register', 'apply', 'onboard', 'account', 'create account'],
      reply: 'You can start an application right now — it takes about 5 minutes and covers your details, security, and a quick review step. Head to <a href="signup.html">Sign up</a>. We\'re in our setup phase, so activation is confirmed by our onboarding team.' },
    { keys: ['log in', 'login', 'sign in', 'password', 'forgot'],
      reply: 'You can log in from the <a href="login.html">Log in</a> page. Live account access is rolling out to Phase 1 pilot clients first — if you\'re an approved merchant and get stuck, WhatsApp our team and we\'ll sort it out.' },
    { keys: ['api', 'developer', 'sdk', 'integrate', 'sandbox', 'webhook'],
      reply: 'Our public API and sandbox are on the roadmap, just beyond Phase 1. You can see the plan and request early access on the <a href="developers.html">Developers</a> page.' },
    { keys: ['phase 1', 'roadmap', 'launch', 'live', 'available', 'status'],
      reply: 'AM-Pay is in its setup phase. Phase 1 (live now) covers DebiCheck, Pay Now and digital client onboarding via our Netcash ISV partnership. Everything else — payroll, payment links, the API, savings and lending — is on the roadmap. More on <a href="about.html">About</a>.' },
    { keys: ['who are you', 'about', 'company', 'albatross', 'moz bit guru', 'network'],
      reply: 'AM-Pay™ Network is a collaboration between Albatross Money and Moz Bit Guru, building payment infrastructure for South African SMEs, micro-merchants, township businesses and agriculture-linked enterprises. Read more on <a href="about.html">About</a>.' },
    { keys: ['contact', 'phone', 'email', 'call', 'reach', 'support', 'help', 'human', 'agent'],
      reply: 'Happy to connect you. Call 011 894 1087, email <a href="mailto:info@albatrossmoney.com">info@albatrossmoney.com</a>, or use the green WhatsApp button for the fastest reply. Full details on <a href="contact.html">Contact</a>.' },
    { keys: ['whatsapp'],
      reply: 'Tap the green WhatsApp button in the corner, or <a href="https://wa.me/27817366447" target="_blank" rel="noopener">click here to chat on WhatsApp</a>.' },
    { keys: ['hi', 'hello', 'hey', 'howzit', 'sawubona'],
      reply: 'Hi there 👋 I\'m the AM-Pay Assistant. Ask me about pricing, DebiCheck, signing up, or how AM-Pay works — or tap a suggestion below.' },
    { keys: ['thank', 'thanks', 'cheers'],
      reply: 'You\'re welcome! Anything else I can help with?' },
    { keys: ['bye', 'goodbye'],
      reply: 'Cheers for stopping by — reach out any time.' }
  ];

  function botReply(text) {
    const t = text.toLowerCase();
    const hit = KB.find(entry => entry.keys.some(k => t.includes(k)));
    if (hit) return hit.reply;
    return 'I don\'t have a canned answer for that yet — I\'m a simple assistant while AM-Pay is in its setup phase. Your best bet is our team directly: <a href="https://wa.me/27817366447" target="_blank" rel="noopener">WhatsApp us</a> or visit <a href="contact.html">Contact</a>.';
  }

  function appendMsg(text, who) {
    if (!chatBody) return;
    const el = document.createElement('div');
    el.className = `chat-msg ${who}`;
    el.innerHTML = text;
    chatBody.appendChild(el);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  function sendUserMessage(text) {
    if (!text || !text.trim()) return;
    appendMsg(text.replace(/</g, '&lt;'), 'user');
    if (chatInput) chatInput.value = '';

    const typing = document.createElement('div');
    typing.className = 'chat-typing';
    typing.innerHTML = '<span></span><span></span><span></span>';
    chatBody.appendChild(typing);
    chatBody.scrollTop = chatBody.scrollHeight;

    setTimeout(() => {
      typing.remove();
      appendMsg(botReply(text), 'bot');
    }, 550 + Math.random() * 350);
  }

  if (chatForm) {
    chatForm.addEventListener('submit', (e) => {
      e.preventDefault();
      sendUserMessage(chatInput ? chatInput.value : '');
    });
  }

  document.querySelectorAll('.chat-chip').forEach(chip => {
    chip.addEventListener('click', () => sendUserMessage(chip.textContent));
  });

});

/* ---------- Homepage hero: live payment-flow dashboard (Customer -> Gateway -> Merchant/Bank -> Settlement) ----------
   Purely cosmetic — jitters a few metric numbers on a timer so the hero reads as a "live" system.
   No-ops on every page except index.html, where the #m-* nodes actually exist. */
document.addEventListener('DOMContentLoaded', () => {
  const latencyEl = document.getElementById('m-latency');
  const fraudEl = document.getElementById('m-fraud');
  const volumeEl = document.getElementById('m-volume');
  const authEl = document.getElementById('m-auth');
  const statusDot = document.getElementById('m-status-dot');
  const statusText = document.getElementById('m-status-text');
  if (!latencyEl) return;

  let volume = 48120;
  const fmtRand = (n) => 'R ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  setInterval(() => {
    latencyEl.textContent = (96 + Math.round(Math.random() * 46)) + 'ms';
  }, 1700);

  setInterval(() => {
    fraudEl.textContent = (0.01 + Math.random() * 0.045).toFixed(2);
  }, 2100);

  setInterval(() => {
    volume += 80 + Math.round(Math.random() * 620);
    volumeEl.textContent = fmtRand(volume);
  }, 2600);

  setInterval(() => {
    const declined = Math.random() < 0.12;
    const auth = declined ? (91 + Math.random() * 2) : (95 + Math.random() * 3.5);
    authEl.textContent = auth.toFixed(0) + '%';
    if (statusDot && statusText) {
      statusDot.classList.toggle('declined', declined);
      statusText.textContent = declined ? 'Declined' : 'Approved';
    }
  }, 2900);
});
