import json

# ---------- node rects (x, y, w, h) within a shared canvas ----------
NODES = {
    "customer":   dict(x=0,   y=76,  w=134, h=112),
    "gateway":    dict(x=196, y=0,   w=176, h=158),
    "merchant":   dict(x=430, y=76,  w=134, h=112),
    "bank":       dict(x=196, y=222, w=176, h=118),
    "settlement": dict(x=430, y=244, w=150, h=112),
}
CANVAS_W, CANVAS_H = 580, 400

def edge_point(node, side):
    n = NODES[node]
    cx, cy = n["x"] + n["w"] / 2, n["y"] + n["h"] / 2
    if side == "left":   return (n["x"], cy)
    if side == "right":  return (n["x"] + n["w"], cy)
    if side == "top":    return (cx, n["y"])
    if side == "bottom": return (cx, n["y"] + n["h"])
    return (cx, cy)

def center(node):
    n = NODES[node]
    return (n["x"] + n["w"] / 2, n["y"] + n["h"] / 2)

EDGES = [
    ("customer", "right", "gateway", "left", "cg"),
    ("gateway", "right", "merchant", "left", "gm"),
    ("gateway", "bottom", "bank", "top", "gb"),
    ("bank", "right", "settlement", "left", "bs"),
]

def path_for(edge):
    a_node, a_side, b_node, b_side, key = edge
    p1 = edge_point(a_node, a_side)
    p2 = edge_point(b_node, b_side)
    # simple elbow: straight if aligned, else one bend
    x1, y1 = p1; x2, y2 = p2
    if abs(y1 - y2) < 1 or abs(x1 - x2) < 1:
        d = f"M{x1:.1f},{y1:.1f} L{x2:.1f},{y2:.1f}"
    else:
        mx = (x1 + x2) / 2
        d = f"M{x1:.1f},{y1:.1f} L{mx:.1f},{y1:.1f} L{mx:.1f},{y2:.1f} L{x2:.1f},{y2:.1f}"
    return key, d, p1, p2

edges_out = [path_for(e) for e in EDGES]

with open("layout.json", "w") as f:
    json.dump({
        "nodes": NODES, "canvas": [CANVAS_W, CANVAS_H],
        "edges": [{"key": k, "d": d, "p1": p1, "p2": p2} for k, d, p1, p2 in edges_out]
    }, f, indent=2)

print("wrote layout.json")
for k, d, p1, p2 in edges_out:
    print(k, d)
