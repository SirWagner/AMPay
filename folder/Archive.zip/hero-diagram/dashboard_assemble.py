import json

with open("layout.json") as f:
    L = json.load(f)

NODES = L["nodes"]; CW, CH = L["canvas"]; EDGES = L["edges"]

# ---------- flat icon glyphs (24x24 viewBox, centered) ----------
def icon_phone():
    return '''<svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
    <rect x="7" y="2.5" width="10" height="19" rx="2.4"/>
    <line x1="10.2" y1="19" x2="13.8" y2="19" stroke-width="1.9"/>
  </svg>'''

def icon_shield_lock():
    return '''<svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
    <path d="M12 2.4 L20 5.6 V11.4 C20 16.4 16.6 20 12 21.6 C7.4 20 4 16.4 4 11.4 V5.6 Z"/>
    <rect x="9" y="11" width="6" height="5.2" rx="1.1" fill="#ffffff" stroke="none"/>
    <path d="M10 11 V9.2 A2 2 0 0 1 14 9.2 V11" />
  </svg>'''

def icon_storefront():
    return '''<svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
    <path d="M3.5 8.2 L4.6 3.6 H19.4 L20.5 8.2" />
    <path d="M3.5 8.2 A2.5 2.5 0 0 0 8.5 8.2 A2.5 2.5 0 0 0 13.5 8.2 A2.5 2.5 0 0 0 18.5 8.2 A2.5 2.5 0 0 0 20.5 8.2" />
    <path d="M4.6 8.6 V20.4 H19.4 V8.6" />
    <rect x="10.2" y="13.6" width="3.6" height="6.8" fill="#0d1a38" stroke="none"/>
  </svg>'''

def icon_bank():
    return '''<svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
    <path d="M2.5 9 L12 3 L21.5 9 Z" />
    <line x1="2.2" y1="9.2" x2="21.8" y2="9.2" />
    <line x1="5" y1="11.5" x2="5" y2="18.5" />
    <line x1="9.4" y1="11.5" x2="9.4" y2="18.5" />
    <line x1="14.6" y1="11.5" x2="14.6" y2="18.5" />
    <line x1="19" y1="11.5" x2="19" y2="18.5" />
    <line x1="2.2" y1="20.6" x2="21.8" y2="20.6" stroke-width="1.9"/>
  </svg>'''

def icon_vault():
    return '''<svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="3"/>
    <circle cx="12" cy="12" r="4.4"/>
    <circle cx="12" cy="12" r="1.1" fill="#ffffff" stroke="none"/>
    <line x1="12" y1="7.6" x2="12" y2="9.1"/>
  </svg>'''

# ---------- node content ----------
def node_html(key, extra_class, icon_svg, title, sub, body_html):
    n = NODES[key]
    return (f'<div class="hd-node hd-node--{extra_class}" style="left:{n["x"]}px; top:{n["y"]}px; width:{n["w"]}px; height:{n["h"]}px;">'
            f'<div class="hd-node-head"><div class="hd-node-icon">{icon_svg}</div>'
            f'<div><div class="hd-node-title">{title}</div><div class="hd-node-sub">{sub}</div></div></div>'
            f'{body_html}</div>')

rail_icons = {
    "card": '<svg viewBox="0 0 24 24" fill="none" stroke="#bff2b0" stroke-width="2"><rect x="3" y="6" width="18" height="13" rx="2"/><line x1="3" y1="10.5" x2="21" y2="10.5" stroke-width="2.6"/></svg>',
    "bolt": '<svg viewBox="0 0 24 24" fill="#bff2b0"><path d="M13 2 L4 14 H11 L9.5 22 L20 9 H13 Z"/></svg>',
    "qr":   '<svg viewBox="0 0 24 24" fill="none" stroke="#bff2b0" stroke-width="2"><path d="M4 9 V4 H9"/><path d="M20 9 V4 H15"/><path d="M4 15 V20 H9"/><path d="M20 15 V20 H15"/><rect x="10.5" y="10.5" width="3" height="3" fill="#bff2b0" stroke="none"/></svg>',
    "repeat": '<svg viewBox="0 0 24 24" fill="none" stroke="#bff2b0" stroke-width="2" stroke-linecap="round"><path d="M4 9 A8 8 0 0 1 18.5 5"/><path d="M18.5 5 L19.5 9.5 L15 8"/><path d="M20 15 A8 8 0 0 1 5.5 19"/><path d="M5.5 19 L4.5 14.5 L9 16"/></svg>',
}

customer_body = ('<div class="hd-metric"><span class="hd-metric-val" id="m-latency">118ms</span></div>'
                  '<div class="hd-metric-lbl">Round-trip latency</div>')
customer = node_html("customer", "customer", icon_phone(), "Customer", "Checkout initiated", customer_body)

gateway_body = ('<div class="hd-ring"></div><div class="hd-ring r2"></div><div class="hd-ring r3"></div>'
                 '<div class="hd-metric"><span class="hd-metric-val" id="m-fraud">0.02</span></div>'
                 '<div class="hd-metric-lbl">Fraud risk score</div>'
                 '<div class="hd-rails">'
                 + "".join(f'<div class="hd-rail-chip">{svg}</div>' for svg in rail_icons.values())
                 + '</div>')
gateway = node_html("gateway", "gateway", icon_shield_lock(), "AM-Pay Gateway", "Orchestration &amp; encryption", gateway_body)

merchant_body = ('<div class="hd-metric"><span class="hd-metric-val" id="m-volume">R 48,120</span></div>'
                   '<div class="hd-metric-lbl">Volume processed today</div>')
merchant = node_html("merchant", "merchant", icon_storefront(), "Merchant", "Order confirmed", merchant_body)

bank_body = ('<div class="hd-metric"><span class="hd-metric-val" id="m-auth">95%</span></div>'
              '<div class="hd-metric-lbl">Authorisation rate</div>'
              '<div class="hd-status"><span class="hd-status-dot" id="m-status-dot"></span><span id="m-status-text">Approved</span></div>')
bank = node_html("bank", "bank", icon_bank(), "Issuing Bank", "Authorising payment", bank_body)

settlement_body = ('<div style="display:flex; align-items:center; gap:8px;">'
                     '<div class="hd-coins"><div class="hd-coin"></div><div class="hd-coin c2"></div><div class="hd-coin c3"></div></div>'
                     '<div><div class="hd-metric-val" style="font-size:12.5px;">Funds settled</div>'
                     '<div class="hd-metric-lbl">T+0 to merchant wallet</div></div></div>')
settlement = node_html("settlement", "settlement", icon_vault(), "Settlement", "Funds released", settlement_body)

nodes_html = customer + gateway + merchant + bank + settlement

# ---------- SVG connector lines ----------
svg_parts = [f'<svg class="hd-grid-svg" viewBox="0 0 {CW} {CH}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">']
for e in EDGES:
    cls = "hd-line--g" if e["key"] != "cg" else "hd-line--b"
    svg_parts.append(f'<path id="path-{e["key"]}" class="hd-line {cls}" d="{e["d"]}"/>')
svg_parts.append("</svg>")
svg_html = "".join(svg_parts)

# ---------- travelling dots (CSS offset-path, using each path's own d) ----------
dot_specs = [
    ("cg", "b", 0.0),
    ("gm", "g", 0.3),
    ("gb", "g", 0.9),
    ("bs", "g", 1.6),
]
dots = []
style_extra = ["<style>"]
for key, color, delay in dot_specs:
    e = next(x for x in EDGES if x["key"] == key)
    cls = f"path-anim-{key}"
    style_extra.append(
        f'.{cls} {{ offset-path: path("{e["d"]}"); animation: travel 2.6s linear {delay:.2f}s infinite; }}'
    )
    dots.append(f'<div class="hd-dot hd-dot--{color} {cls}"></div>')
style_extra.append("</style>")
dots_html = "".join(style_extra) + "".join(dots)

# ---------- JS: live metric updates ----------
js = '''
(function () {
  var latencyEl = document.getElementById("m-latency");
  var fraudEl = document.getElementById("m-fraud");
  var volumeEl = document.getElementById("m-volume");
  var authEl = document.getElementById("m-auth");
  var statusDot = document.getElementById("m-status-dot");
  var statusText = document.getElementById("m-status-text");
  if (!latencyEl) return;

  var volume = 48120;

  function fmtRand(n) {
    return "R " + Math.round(n).toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g, ",");
  }

  setInterval(function () {
    var latency = 96 + Math.round(Math.random() * 46);
    latencyEl.textContent = latency + "ms";
  }, 1700);

  setInterval(function () {
    var fraud = (0.01 + Math.random() * 0.045).toFixed(2);
    fraudEl.textContent = fraud;
  }, 2100);

  setInterval(function () {
    volume += 80 + Math.round(Math.random() * 620);
    volumeEl.textContent = fmtRand(volume);
  }, 2600);

  setInterval(function () {
    var declined = Math.random() < 0.12;
    var auth = declined ? (91 + Math.random() * 2) : (95 + Math.random() * 3.5);
    authEl.textContent = auth.toFixed(0) + "%";
    if (statusDot && statusText) {
      statusDot.classList.toggle("declined", declined);
      statusText.textContent = declined ? "Declined" : "Approved";
    }
  }, 2900);
})();
'''

with open("preview.html") as f:
    tpl = f.read()

tpl = tpl.replace("__SVG__", svg_html).replace("__DOTS__", dots_html).replace("__NODES__", nodes_html).replace("__JS__", js)

with open("preview_out.html", "w") as f:
    f.write(tpl)

print("wrote preview_out.html")
