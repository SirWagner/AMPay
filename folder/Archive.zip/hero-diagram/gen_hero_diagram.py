import math, random

# ---------- palette ----------
GREEN_TOP, GREEN_LEFT, GREEN_RIGHT = "#6fd15e", "#4aaa3c", "#356b2a"
NAVY_TOP, NAVY_LEFT, NAVY_RIGHT = "#3a5aa8", "#274d94", "#16264e"
NAVY2_TOP, NAVY2_LEFT, NAVY2_RIGHT = "#2e4c8f", "#1e3674", "#0f1c3e"
NAVY3_TOP, NAVY3_LEFT, NAVY3_RIGHT = "#345191", "#22407e", "#121f45"
FOUND_TOP, FOUND_LEFT, FOUND_RIGHT = "#1c2f5e", "#132447", "#0a152e"
WALL_TOP, WALL_LEFT, WALL_RIGHT = "#33528f", "#223f7a", "#12224a"
ROOF_TOP, ROOF_LEFT, ROOF_RIGHT = "#4aaa3c", "#3d9230", "#2a6b21"

def pts(*p):
    return " ".join(f"{x:.1f},{y:.1f}" for x, y in p)

def iso_box(ox, oy, w, h, depth, top, left, right):
    """Isometric box: diamond top + two shaded side faces. Returns svg + reference points."""
    N = (ox, oy - h / 2); E = (ox + w / 2, oy); S = (ox, oy + h / 2); W = (ox - w / 2, oy)
    Sd = (S[0], S[1] + depth); Wd = (W[0], W[1] + depth); Ed = (E[0], E[1] + depth)
    svg = (
        f'<polygon points="{pts(S,E,Ed,Sd)}" fill="{right}"/>'
        f'<polygon points="{pts(W,S,Sd,Wd)}" fill="{left}"/>'
        f'<polygon points="{pts(N,E,S,W)}" fill="{top}" stroke="rgba(13,26,56,0.35)" stroke-width="0.6"/>'
    )
    d = {"N": N, "E": E, "S": S, "W": W, "Sd": Sd, "Wd": Wd, "Ed": Ed, "center": (ox, oy), "w": w, "h": h, "depth": depth}
    return svg, d

def lerp(p1, p2, t):
    return (p1[0] + (p2[0]-p1[0])*t, p1[1] + (p2[1]-p1[1])*t)

# ---------- decorations ----------
def roof_pediment(d, rise=22, color_top=ROOF_TOP, color_left=ROOF_LEFT, color_right=ROOF_RIGHT):
    """Triangular pediment roof sitting directly on the box's top diamond (bank-style)."""
    N, E, W = d["N"], d["E"], d["W"]
    apex = (N[0], N[1] - rise)
    left_face = f'<polygon points="{pts(W,N,apex)}" fill="{color_left}"/>'
    right_face = f'<polygon points="{pts(N,E,apex)}" fill="{color_top}"/>'
    ridge = f'<line x1="{N[0]:.1f}" y1="{N[1]:.1f}" x2="{apex[0]:.1f}" y2="{apex[1]:.1f}" stroke="{color_right}" stroke-width="1" opacity="0.5"/>'
    return left_face + right_face + ridge

def awning(d, band=15, colorA="#eaf6e7", colorB="#4aaa3c"):
    """Striped awning band along the front-left (W-S) face, near the top."""
    W, S, Wd, Sd = d["W"], d["S"], d["Wd"], d["Sd"]
    W2 = lerp(W, Wd, band / d["depth"])
    S2 = lerp(S, Sd, band / d["depth"])
    base = f'<polygon points="{pts(W,S,S2,W2)}" fill="{colorB}"/>'
    n = 5
    stripes = []
    for i in range(n):
        t0 = i / n; t1 = (i + 0.5) / n
        p0 = lerp(W, S, t0); p1 = lerp(W, S, t1)
        p0d = lerp(W2, S2, t0); p1d = lerp(W2, S2, t1)
        stripes.append(f'<polygon points="{pts(p0,p1,p1d,p0d)}" fill="{colorA}" opacity="0.85"/>')
    return base + "".join(stripes)

def door(d, color="#0a152e"):
    S, E, Sd, Ed = d["S"], d["E"], d["Sd"], d["Ed"]
    t0, t1 = 0.38, 0.62
    p0, p1 = lerp(S, E, t0), lerp(S, E, t1)
    p0d, p1d = lerp(Sd, Ed, t0), lerp(Sd, Ed, min(1.0, t1))
    depth_frac = 0.72
    p0d = lerp(p0, p0d, depth_frac); p1d = lerp(p1, p1d, depth_frac)
    return f'<polygon points="{pts(p0,p1,p1d,p0d)}" fill="{color}" opacity="0.9"/>'

def columns(d, n=3, color="rgba(255,255,255,0.55)"):
    S, E, Sd, Ed = d["S"], d["E"], d["Sd"], d["Ed"]
    lines = []
    for i in range(1, n + 1):
        t = i / (n + 1)
        top = lerp(S, E, t)
        bot = lerp(Sd, Ed, t)
        bot = lerp(top, bot, 0.82)
        lines.append(f'<line x1="{top[0]:.1f}" y1="{top[1]:.1f}" x2="{bot[0]:.1f}" y2="{bot[1]:.1f}" stroke="{color}" stroke-width="1.6" stroke-linecap="round"/>')
    return "".join(lines)

def rack_slits(d, n=3, color="rgba(255,255,255,0.35)"):
    W, S, Wd, Sd = d["W"], d["S"], d["Wd"], d["Sd"]
    lines = []
    for i in range(1, n + 1):
        t = i / (n + 1)
        a = lerp(W, Wd, t); b = lerp(S, Sd, t)
        lines.append(f'<line x1="{a[0]:.1f}" y1="{a[1]:.1f}" x2="{b[0]:.1f}" y2="{b[1]:.1f}" stroke="{color}" stroke-width="1.4"/>')
    return "".join(lines)

# ---------- icons (small, ~24 units) ----------
def icon_lock(cx, cy, s=1.0, color="#ffffff"):
    return f'''<g transform="translate({cx:.1f},{cy:.1f}) scale({s})" stroke="{color}" stroke-width="1.7" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <rect x="-6" y="-1.5" width="12" height="9.5" rx="1.6"/>
    <path d="M-3.6,-1.5 V-4.5 A3.6,3.6 0 0 1 3.6,-4.5 V-1.5"/>
    <circle cx="0" cy="3" r="1.15" fill="{color}" stroke="none"/>
  </g>'''

def icon_bolt(cx, cy, s=1.0, color="#ffffff"):
    return f'<g transform="translate({cx:.1f},{cy:.1f}) scale({s})"><path d="M1.5,-10 L-7,2 H-0.8 L-1.8,10 L8,-2 H1.2 Z" fill="{color}"/></g>'

def icon_repeat(cx, cy, s=1.0, color="#ffffff"):
    return f'''<g transform="translate({cx:.1f},{cy:.1f}) scale({s})" stroke="{color}" stroke-width="1.7" fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path d="M-7,-1.5 A7.5,7.5 0 0 1 6.5,-6.5" /><path d="M6.5,-6.5 L7.2,-2.2 L3,-3.6 Z" fill="{color}" stroke="none"/>
    <path d="M7,1.5 A7.5,7.5 0 0 1 -6.5,6.5" /><path d="M-6.5,6.5 L-7.2,2.2 L-3,3.6 Z" fill="{color}" stroke="none"/>
  </g>'''

def icon_qr(cx, cy, s=1.0, color="#ffffff"):
    def corner(rot):
        return f'<path d="M-6,-2 V-6 H-2" stroke="{color}" stroke-width="1.7" fill="none" stroke-linecap="round" transform="rotate({rot})"/>'
    return f'<g transform="translate({cx:.1f},{cy:.1f}) scale({s})">{corner(0)}{corner(90)}{corner(180)}{corner(270)}<rect x="-1.6" y="-1.6" width="3.2" height="3.2" fill="{color}"/></g>'

def icon_card(cx, cy, s=1.0, color="#ffffff"):
    return f'''<g transform="translate({cx:.1f},{cy:.1f}) scale({s})" stroke="{color}" stroke-width="1.6" fill="none" stroke-linejoin="round">
    <rect x="-9" y="-6.5" width="18" height="13" rx="2.2"/>
    <line x1="-9" y1="-2.2" x2="9" y2="-2.2" stroke-width="2.4"/>
    <line x1="-6" y1="2.8" x2="-1" y2="2.8" stroke-width="1.6"/>
  </g>'''

ICONS = {"bolt": icon_bolt, "repeat": icon_repeat, "qr": icon_qr, "card": icon_card}

def label(cx, cy, text, size=11, color="rgba(255,255,255,0.85)", weight="700", anchor="middle"):
    return (f'<text class="iso-label" x="{cx:.1f}" y="{cy:.1f}" font-family="Arial, Helvetica, sans-serif" '
            f'font-size="{size}" font-weight="{weight}" fill="{color}" text-anchor="{anchor}" '
            f'letter-spacing="0.2">{text}</text>')

def elbow3(p1, turn_x, p2):
    x1, y1 = p1; x2, y2 = p2
    return f"M{x1:.1f},{y1:.1f} L{turn_x:.1f},{y1:.1f} L{turn_x:.1f},{y2:.1f} L{x2:.1f},{y2:.1f}"

def elbow(p1, p2, bend="v"):
    x1, y1 = p1; x2, y2 = p2
    mx, my = (x2, y1) if bend == "v" else (x1, y2)
    return f"M{x1:.1f},{y1:.1f} L{mx:.1f},{my:.1f} L{x2:.1f},{y2:.1f}"

VIEW_W, VIEW_H = 560, 540
# phone box (must match preview CSS: right:10 bottom:20 width:200 height:320, in a VIEW_H-tall canvas)
PHONE_LEFT = VIEW_W - 10 - 200   # 350
PHONE_TOP = VIEW_H - 20 - 320    # 200

parts = [f'<svg class="iso-scene-svg" viewBox="0 0 {VIEW_W} {VIEW_H}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">']

# background deco dots
random.seed(21)
deco = []
for _ in range(18):
    x = random.uniform(10, VIEW_W - 10); y = random.uniform(10, VIEW_H - 10)
    r = random.uniform(1, 2.1); o = random.uniform(0.06, 0.2)
    deco.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" fill="#ffffff" opacity="{o:.2f}"/>')
parts.append('<g class="iso-deco">' + "".join(deco) + '</g>')

# ---------- 1. Merchant storefront (left) ----------
merch_svg, merch_d = iso_box(80, 300, 130, 64, 64, WALL_TOP, WALL_LEFT, WALL_RIGHT)
merch_extra = awning(merch_d, band=15) + door(merch_d)
merch_group = (f'<g class="iso-platform iso-platform--merchant">{merch_svg}{merch_extra}'
               f'{label(80, merch_d["S"][1] + merch_d["depth"] + 22, "MERCHANT")}</g>')

# ---------- 2. Payment rails -- single column between merchant and gateway ----------
rails = [
    ("card",   195, 108, 64, 32, 14, (NAVY_TOP, NAVY_LEFT, NAVY_RIGHT),   "Card"),
    ("bolt",   195, 198, 64, 32, 14, (NAVY3_TOP, NAVY3_LEFT, NAVY3_RIGHT),"Instant EFT"),
    ("qr",     195, 288, 64, 32, 14, (NAVY2_TOP, NAVY2_LEFT, NAVY2_RIGHT),"PayShap"),
    ("repeat", 195, 378, 64, 32, 14, (NAVY_TOP, NAVY_LEFT, NAVY_RIGHT),   "DebiCheck"),
]
rail_nodes = {}
rail_group_parts = []
for key, ox, oy, w, h, depth, colors, lbl in rails:
    top, left, right = colors
    svg, d = iso_box(ox, oy, w, h, depth, top, left, right)
    rail_nodes[key] = d
    rail_group_parts.append(f'<g class="iso-platform iso-platform--{key}">{svg}{ICONS[key](ox, oy - 2, 0.95)}{label(ox, d["S"][1] + depth + 16, lbl, 9.5)}</g>')

# ---------- 3. AM-Pay Gateway tower (tall, center) ----------
GX = 270  # shared x-axis for the gateway / foundation / bank stack -- kept well clear of the phone
gate_svg, gate_d = iso_box(GX, 140, 64, 34, 120, GREEN_TOP, GREEN_LEFT, GREEN_RIGHT)
gate_extra = rack_slits(gate_d, n=4, color="rgba(255,255,255,0.32)") + icon_lock(gate_d["center"][0], gate_d["center"][1] - 3, 1.15, "#ffffff")
gate_label_y = gate_d["S"][1] + gate_d["depth"] + 14
gate_group = (f'<g class="iso-platform iso-platform--hub">{gate_svg}{gate_extra}'
              f'{label(GX, gate_label_y, "AM-PAY GATEWAY", 10, "#ffffff", weight="800")}</g>')

# compliance foundation pad, well clear of the gateway label above it
gate_found_svg, gate_found_d = iso_box(GX, gate_d["Sd"][1] + 50, 100, 28, 12, FOUND_TOP, FOUND_LEFT, FOUND_RIGHT)
found_group = (f'<g class="iso-platform iso-foundation">{gate_found_svg}'
               f'{label(GX, gate_found_d["S"][1] + gate_found_d["depth"] + 18, "NCRCP9166 · FSP NO.6630", 7.6, "rgba(255,255,255,0.42)", weight="400")}</g>')

# ---------- 4. Settlement bank (below gateway, clear of the phone) ----------
bank_svg, bank_d = iso_box(GX, gate_found_d["Sd"][1] + 80, 92, 44, 38, WALL_TOP, WALL_LEFT, WALL_RIGHT)
bank_extra = roof_pediment(bank_d, rise=18) + columns(bank_d, n=3)
bank_group = (f'<g class="iso-platform iso-platform--bank">{bank_svg}{bank_extra}'
              f'{label(GX, bank_d["S"][1] + bank_d["depth"] + 22, "SETTLEMENT")}</g>')

# ---------- connectors ----------
landing = gate_d["W"]  # rails converge into the gateway's west face
connector_parts = []
pulse_parts = []
for i, (key, *_r) in enumerate(rails):
    d = rail_nodes[key]
    p = d["center"]
    d_path = elbow(p, landing, bend="v")
    connector_parts.append(f'<path d="{d_path}" fill="none" stroke="rgba(255,255,255,0.20)" stroke-width="1.3" stroke-dasharray="1.5 5" stroke-linecap="round"/>')
    connector_parts.append(f'<circle cx="{p[0]:.1f}" cy="{p[1]:.1f}" r="2.2" fill="rgba(255,255,255,0.6)"/>')
    mx, my = landing[0], p[1]
    pulse_parts.append(f'<circle class="iso-pulse" style="animation-delay:{i*0.4:.2f}s" cx="{mx:.1f}" cy="{my:.1f}" r="2.4" fill="#bff2b0"/>')
connector_parts.append(f'<circle cx="{landing[0]:.1f}" cy="{landing[1]:.1f}" r="3.6" fill="rgba(74,170,60,0.5)"/>')

# gateway -> bank (straight down through the compliance pad)
d_bank = f'M{gate_d["Sd"][0]:.1f},{gate_d["Sd"][1]:.1f} L{bank_d["N"][0]:.1f},{bank_d["N"][1]:.1f}'
connector_parts.append(f'<path d="{d_bank}" fill="none" stroke="rgba(126,224,127,0.55)" stroke-width="1.6" stroke-dasharray="1.5 5" stroke-linecap="round"/>')
mid_bank = ((gate_d["Sd"][1] + bank_d["N"][1]) / 2)
pulse_parts.append(f'<circle class="iso-pulse" style="animation-delay:2.0s" cx="{gate_d["Sd"][0]:.1f}" cy="{mid_bank:.1f}" r="2.8" fill="#7be07f"/>')

# bank -> phone (settled funds reflected back to the customer's receipt)
phone_hub = (PHONE_LEFT, 340)
turn_x = PHONE_LEFT - 8
d_phone = elbow3((bank_d["E"][0] + 6, bank_d["center"][1]), turn_x, phone_hub)
connector_parts.append(f'<path d="{d_phone}" fill="none" stroke="rgba(126,224,127,0.5)" stroke-width="1.5" stroke-dasharray="1.5 5" stroke-linecap="round"/>')
pulse_parts.append(f'<circle class="iso-pulse" style="animation-delay:2.4s" cx="{turn_x:.1f}" cy="{bank_d["center"][1]:.1f}" r="2.6" fill="#7be07f"/>')

parts.append('<g class="iso-connectors">' + "".join(connector_parts) + "".join(pulse_parts) + '</g>')
parts.append(merch_group)
for g in rail_group_parts:
    parts.append(g)
parts.append(found_group)
parts.append(gate_group)
parts.append(bank_group)

parts.append('</svg>')

with open("scene3.svg.txt", "w") as f:
    f.write("\n".join(parts))
print("wrote scene3.svg.txt", VIEW_W, VIEW_H, "phone_left", PHONE_LEFT, "phone_top", PHONE_TOP)
